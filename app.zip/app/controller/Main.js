Ext.define('DemoApp.controller.Main', {
    extend: 'Ext.app.Controller'
});
