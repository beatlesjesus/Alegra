Ext.define('AM.view.Viewport', {
    extend: 'AM.view.GrillaViewport',
    renderTo: Ext.getBody()
});